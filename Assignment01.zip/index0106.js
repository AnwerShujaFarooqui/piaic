//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 01 : Q # 0106         -->
//<!-- Doc id #      : index0106.js       -->

//<!-- Notes         :  Program : JavaScript script age alert -->

//----------------------------- Program JavaScript -----------------------------------------------

//                      Program : JavaScript script age alert

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        var yob = prompt("What is your year of birth  ? ");

        document.writeln('<h2>');

        document.writeln("My birth year is " + yob);

        document.writeln(LineBreak);
        document.writeln(LineBreak);

        document.writeln("Data type of my ddeclared variable is number");

        document.writeln('</h2>');

//------------------------------------------------------------------------------------------------------
