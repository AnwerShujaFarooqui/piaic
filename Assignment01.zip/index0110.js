//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 01 : Q # 0110         -->
//<!-- Doc id #      : index0110.js       -->

//<!-- Notes         :  Program : Two Numbers Subtraction, Multiply, Division and Modulus Result -->

//----------------------------- Program JavaScript -----------------------------------------------

//                      Program : Two Numbers Subtraction, Multiply, Division and Modulus Result

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        document.writeln('<h2>');
 
        var num1 = 5;
      
        document.writeln("Value after variable declaration is undefined");
        document.writeln(LineBreak);
        document.writeln(LineBreak);

//--------------------- Initial Value ----------------------------------

        document.writeln("Intial value : " + num1);
        document.writeln(LineBreak);
        document.writeln(LineBreak);

//--------------------- Value Increment ----------------------------------

        num1++;    // add 1 in num1

        document.writeln("Value after increment is : " + num1);
        document.writeln(LineBreak);
        document.writeln(LineBreak);

//--------------------- Additional Increment ----------------------------------

        num1 = num1 + 7;    // add 7 in num1

        document.writeln("Value after addition is : " + num1);
        document.writeln(LineBreak);
        document.writeln(LineBreak);

//--------------------- Value Decrement ----------------------------------

        --num1;    // decrement in num1

        document.writeln("Value after decrement is : " + num1);
        document.writeln(LineBreak);
        document.writeln(LineBreak);

//--------------------- Value Modulus ----------------------------------

        num1 = num1 % 3;    // the modulus of num1 by 3 shall be

        document.writeln("The remainder is : " + num1);
        document.writeln(LineBreak);
        document.writeln(LineBreak);


        document.writeln('</h2>');

//------------------------------------------------------------------------------------------------------
