//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 01 : Q # 0107         -->
//<!-- Doc id #      : index0107.js       -->

//<!-- Notes         :  Program : JavaScript script age alert -->

//----------------------------- Program JavaScript -----------------------------------------------

//                      Program : JavaScript script age alert

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        document.writeln('<h1>');
        document.writeln("Rules for naming JS variables");
        document.writeln('</h1>');


        document.writeln('<h2>');

        document.writeln("Variables name can only contain, numbers, $ and _. For example : $my_1stVariable");
        document.writeln(LineBreak);
        document.writeln(LineBreak);

        document.writeln("Variables must begin with a letter, $ and _. For example : $name, _name or name");
        document.writeln(LineBreak);
        document.writeln(LineBreak);

        document.writeln("Variables names are case sensitive");
        document.writeln(LineBreak);
        document.writeln(LineBreak);

document.writeln("Variables names should not be JS keywords");
document.writeln(LineBreak);
document.writeln(LineBreak);

        document.writeln('</h2>');

//------------------------------------------------------------------------------------------------------
