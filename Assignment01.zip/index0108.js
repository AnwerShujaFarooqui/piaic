//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 01 : Q # 0108         -->
//<!-- Doc id #      : index0108.js       -->

//<!-- Notes         :  Program : Add Two Numbers and Result in new variable -->

//----------------------------- Program JavaScript -----------------------------------------------

//                      Program : Add Two Numbers and Result in new variable

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        document.writeln('<h2>');
 
        var num1 = Number(prompt("Please enter First No. --> "));
        var num2 = Number(prompt("Please enter Second No. --> "));
        var sum1 = num1 + num2;

        document.writeln("Sum of " + num1 + " and " + num2  + " is " + sum1);

        document.writeln(LineBreak);
  
        document.writeln(LineBreak);

        document.writeln('</h2>');

//------------------------------------------------------------------------------------------------------
