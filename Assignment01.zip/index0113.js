//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 01 : Q # 0113         -->
//<!-- Doc id #      : index0113.js       -->

//<!-- Notes         :  Program : Arithmetic Number -->

/* ----------------------------- Program JavaScript -----------------------------------------------

                       Program : Arithmetic Number
---------------------------------------------------------------------------------------------------

take a number and do various arithmetic 

---------------------------------------------------------------------------------------------------- */


        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        var a = Number(10);          // initial value 

//<!-- ------------------------------------------------------------------------------------------------- -->

        document.writeln('<h2>');
 
        document.writeln(LineBreak);
        document.writeln(LineBreak);

//------------------------------------------------------------------------

        document.writeln(" Result :");

        document.writeln(LineBreak);
        document.writeln("-----------------------------");

        document.writeln(LineBreak);
 
        document.writeln("The value of 'a' is : " + a);
        document.writeln(LineBreak);
        document.writeln("........................................");

        document.writeln(LineBreak);
        document.writeln(LineBreak);
//-----------------------------------------------------------------------------------------------------------

        ++a;
        document.writeln("The value of '++a' is : " + a);
        document.writeln(LineBreak);

        document.writeln("Now the value of 'a' is : " + a);
        document.writeln(LineBreak);

        document.writeln(LineBreak);
        document.writeln(LineBreak);

//-----------------------------------------------------------------------------------------------------------

        //a++;          // ***the remarks was done to get the result as per logic provided
        document.writeln("The value of 'a++' is : " + a);
        document.writeln(LineBreak);

        a++;  // ***
        document.writeln("Now the value of 'a' is : " + a);
        document.writeln(LineBreak);

        document.writeln(LineBreak);
        document.writeln(LineBreak);

//-----------------------------------------------------------------------------------------------------------

        //--a;        // the remarks was done to get the result as per logic provided

        document.writeln("The value of '--a' is : " + a);
        document.writeln(LineBreak);

        --a;  // ***
        document.writeln("Now the value of 'a' is : " + a);
        document.writeln(LineBreak);

        document.writeln(LineBreak);
        document.writeln(LineBreak);

//-----------------------------------------------------------------------------------------------------------

        //a--;          // ***the remarks was done to get the result as per logic provided

        document.writeln("The value of 'a--' is : " + a);
        document.writeln(LineBreak);

        a--; // ***
        document.writeln("Now the value of 'a' is : " + a);
        document.writeln(LineBreak);

        document.writeln(LineBreak);
        document.writeln(LineBreak);


//-----------------------------------------------------------------------------------------------------------

        document.writeln(LineBreak);
        document.writeln(LineBreak);

        document.writeln('</h2>');

//------------------------------------------------------------------------------------------------------
