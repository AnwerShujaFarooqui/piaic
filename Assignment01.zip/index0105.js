//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 01 : Q # 0105         -->
//<!-- Doc id #      : index0105.js       -->

//<!-- Notes         :  Program : JavaScript script check the age -->

//----------------------------- Program JavaScript -----------------------------------------------

//                      Program : JavaScript script check the age

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        var age = prompt("How old are you ? ");

        alert("I am  " + age + " years old");

//------------------------------------------------------------------------------------------------------
