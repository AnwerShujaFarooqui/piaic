//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 02 : Q # 05             -->
//<!-- Doc id #      : index0205.js       -->

//<!-- Notes         : Various Variable   -->


//------------------ other variables to calculate ---------------------------------------

    var a = 4;
    var b = 82;
    var c = 12;
    var linebreak = "<br />";

//~~~~~~~~~~~~~ <<<<< calculations >>>>>> ~~~~~~~~~~~~false~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// ===== Q # 05.a. =====




    document.writeln('<h2>');

if (++a === 5){
        document.writeln(linebreak);
        document.writeln("++a === 5    ...   ---> given condition for variable 'a' is true ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("++a === 5     .....  ~~~> given condition for variable 'a' is false ");
        document.writeln(linebreak);
    }

// ===== Q # 05.b. =====
// when  var b = 82;

    if (b++ === 83) {
        document.writeln(linebreak);
        document.writeln("b++ === 83   ...   ---> given condition for variable 'b' is true ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("b++ === 83   .....   ~~~> given condition for variable 'b' is false ");
        document.writeln(linebreak);
    }

// ===== Q # 05.c. =====
//  when  var c = 12;

    if (c++ === 13) {
        document.writeln(linebreak);
        document.writeln("c++ === 13   ...   --->  given condition '1' is true ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("c++ === 13   .....   ~~~> given condition '1' is false ");
        document.writeln(linebreak);
    }


    if (c === 13) {
        document.writeln(linebreak);
        document.writeln("c === 13   ...   --->  given condition '2' is true ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("c === 13    .....  ~~~>  given condition '2' is false ");
        document.writeln(linebreak);
    }


    if (++c < 14) {
        document.writeln(linebreak);
        document.writeln("++c < 14  ...   --->  given condition '3' is true ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("++c < 14   .....   ~~~>  given condition '3' is false ");
        document.writeln(linebreak);
    }


    if (c === 14) {
        document.writeln(linebreak);
        document.writeln("c === 14   ...    --->  given condition '4' is true ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("c === 14   .....    ~~~>  given condition '4' is false ");
        document.writeln(linebreak);
    }

// ---------------------------------------------------------------

 
// ----------------------------------------------------------------
// ===== Q # 05.d. =====
//  when  var c = 12;



    var materialCost = 20000;
    var laborCost    = 2000;
    var totalCost    = laborCost + materialCost;

    if (totalCost === laborCost + materialCost){{
            document.writeln(linebreak);
            document.writeln("The cost equals --->   ");

        }{ if (true){
            document.writeln(linebreak);
            document.writeln(linebreak);
            document.writeln("True");
            document.writeln(linebreak);

        }else  if (false){
                document.writeln(linebreak);
                document.writeln(linebreak);
                document.writeln("False");
                document.writeln(linebreak);

        }}
    }
    
//-----------------------------------------------------------------

    if ("car" < "cat") {
        document.writeln(linebreak);
        document.writeln("car is smaller than cat ");
        document.writeln(linebreak);
    } else {
        document.writeln(linebreak);
        document.writeln("cat is smaller than car ");

    }

        document.writeln(linebreak);
        document.writeln('</h2>');

//-->

//<p>Set the variables to different values and different operators and then
//try...</p>



// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// -------------------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------------------
