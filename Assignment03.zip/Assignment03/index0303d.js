//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 02 : Q # 0303d           -->
//<!-- Doc id #      : index0303d.js     -->

//<!-- Notes         : Colors to check  -->


//----------------------------- Check The Colors  3d--------------------------------------------------------

//  lets check Colors

//

//==========================================================

        var LineBreak = "<br />";
        
//-------------------------------------------------------------------------------------------------------

        var colors = [" red", " blue", " green", " purple", " yellow", " brown", " pink", " white", " black", " grey"];

//------------------------------------------------------------------------------------------------------------------------------

        document.writeln('<h2>');
        document.writeln("<<< C O L O R S >>>")
        document.writeln('</h2>');

//------------------------------------------------------------------------------------------------------------------------------

        document.writeln(LineBreak);
        document.writeln("<h3>" + "The 'first' color in the array, will deleted:" + "</h3>");
        document.writeln(LineBreak);
 
        colors.shift();
 

        document.writeln('<h3>'  + colors + '</h3>');

        document.writeln(LineBreak);

//--------------------------------------------------------------------------------------------------------------

        document.writeln(LineBreak);

//------------------------------------------------------------------------------------------------------------------------------


//3(D) Delete the first color in the array. Display the updated 
//var colours = [" red", " blue", " green", " purple", " yellow", " brown", " pink", " white", " black"];
//colours.shift();
//document.write(colours);
//document.write("<br>");




//------------------------------------------------------------------------------------------------------------------------------

