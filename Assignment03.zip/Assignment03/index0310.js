//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 02 : Q # 0310           -->
//<!-- Doc id #      : index0310.js       -->

//<!-- Notes         : Sorting Array Query      -->

//----------------------------- Sorted List ------------------------------------------------------

//                          Sorting Array Query

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        var s = [20, 53, 78, 14, 91, 12]

//--------------------------------------------------------------------------------------------------

        document.writeln('<h2>');
        document.writeln("<<< Sorted Numbers List  >>>");

//--------------------------------------------------------------------------------------------------

        document.writeln(LineBreak);
        document.writeln(LineBreak);

    
        document.writeln("Unsorted # list : "+ s); // unsorted list

        document.writeln(LineBreak);
        document.writeln(LineBreak);
        document.writeln(LineBreak);

        console.log("Sorted # are : " + s.sort()); // sorted list on console

        document.writeln("Sorted # are : " + s.sort()); // sorted list view


//--------------------------------------------------------------------------------------------------

        document.writeln("</h2>");

//--------------------------------------------------------------------------------------------------



