//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 02 : Q # 0402          -->
//<!-- Doc id #      : index0402.js       -->

//<!-- Notes         :  Program : To Convert String Value to Numeric -->

//----------------------------- Program JavaScript --------------------------------

//                      Program : To Convert String Value to Numeric

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        var value = ("472");
        var myInteger = parseInt(value);

//----------------------------------------------------

        document.writeln('<h2>');
        document.writeln("<<< To Convert String Value to Numeric  >>>");

//--------------------------------------------------------------------------------------------------

        document.writeln(LineBreak); 
        document.writeln(LineBreak);

        document.writeln("Value: \"" + value + "\"");
        document.writeln(" ===> " +  " Type: " + "\"string\"");   // Before : String Value


        document.writeln(LineBreak); 
        document.writeln(LineBreak);

        document.writeln( "Value: " + myInteger);
        document.writeln(" ~~~~~~> " +  " Type: " + "number");  // After Conversion : Numeric Value

        document.writeln(LineBreak);
        document.writeln(LineBreak);

        document.writeln('</h2>');

//------------------------------------------------
