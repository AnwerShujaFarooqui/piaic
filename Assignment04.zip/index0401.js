//<!-- PIAIC - BlockChain - Semester II   -->

//<!-- Id # : BCC 037581                  -->
//<!-- Name : Anwer Shuja Farooqui        -->

//<!-- Assignment 02 : Q # 0401           -->
//<!-- Doc id #      : index0401.js       -->

//<!-- Notes         :                   -->

//----------------------------- Program JavaScrit --------------------------------

//                          Program 

//=================================================================================================

        var LineBreak = "<br />";

//--------------------------------------------------------------------------------------------------

        var city = "hyderabad"
        var newcity = city.replace("hyder", "islam");

//--------------------------------------------------------------------------------------------------

//----------------------------------------------------

        document.writeln('<h2>');
        document.writeln("<<< City Name  >>>");

//--------------------------------------------------------------------------------------------------

        document.writeln(LineBreak); 
        document.writeln(LineBreak);

        document.writeln("City: " + city);
        document.writeln(LineBreak); 
        document.writeln(LineBreak);
        document.write("After Replacement: " + newcity);

        document.writeln(LineBreak);
        document.writeln(LineBreak);
        document.writeln('</h2>');

//------------------------------------------------


//--------------------------------------------------------------------------------------------------

        //document.writeln("</h2>");

//--------------------------------------------------------------------------------------------------
